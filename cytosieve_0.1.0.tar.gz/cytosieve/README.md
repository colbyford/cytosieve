# *cytosieve* - An R package for _in silico_ cytometric filtering of bulk sequencing data with transcriptional profiles.
<h3 align = "right">Colby T. Ford, Ph.D., Daniel Kepple, Daniel Janies, Ph.D., Eugenia Lo, Ph.D.</h3>
